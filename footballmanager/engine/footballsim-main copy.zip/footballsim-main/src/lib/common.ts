import { logger } from './logger.js';
import type { Ball, BallPosition, MatchDetails, Player } from './types.js';

// -------------------------
// Seedable RNG (Mulberry32)
// -------------------------

// Default to Math.random until a seed is provided
let matchRNG: () => number = Math.random;

/**
 * Initializes the match-wide random number generator with a specific seed.
 * This ensures the entire match simulation is deterministic and repeatable.
 */
function setMatchSeed(seed: number): void {
  matchRNG = function () {
    let t = (seed += 0x6d2b79f5);

    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);

    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// --------------
// Maths Functions
// --------------

function getRandomNumber(min: number, max: number): number {
  // Now uses the seedable matchRNG instead of Math.random()
  return Math.floor(matchRNG() * (max - min + 1)) + min;
}

/**
 * Rounds a number to a specified number of decimal places.
 * Satisfies sonarjs/no-nested-template-literals by using math over string templates.
 */
function round(value: number | string, decimals: number): number {
  const p = Math.pow(10, decimals);

  const n = Number(value) * p;

  const rounded = Math.round(n);

  return rounded / p;
}

function isBetween(num: number, low: number, high: number): boolean {
  return num > low && num < high;
}

function upToMax(num: number, max: number): number {
  if (num > max) {
    return max;
  }

  return num;
}

function upToMin(num: number, min: number): number {
  if (num < min) {
    return min;
  }

  return num;
}

function calculatePower(strength: number | string): number {
  const hit = getRandomNumber(1, 5);

  return Math.floor(Number(strength)) * hit;
}

function aTimesbDividedByC(a: number, b: number, c: number): number {
  return a * (b / sumFrom1toX(c));
}

function sumFrom1toX(x: number): number {
  return (x * (x + 1)) / 2;
}

function inTopPenalty(matchDetails: MatchDetails, item: BallPosition): boolean {
  const [matchWidth, matchHeight] = matchDetails.pitchSize;

  const ballInPenalyBoxX = isBetween(item[0], matchWidth / 4 + 5, matchWidth - matchWidth / 4 - 5);

  const ballInTopPenalyBoxY = isBetween(item[1], -1, matchHeight / 6 + 7);

  return ballInPenalyBoxX && ballInTopPenalyBoxY;
}

function inBottomPenalty(matchDetails: MatchDetails, item: BallPosition): boolean {
  const [matchWidth, matchHeight] = matchDetails.pitchSize;

  const ballInPenalyBoxX = isBetween(item[0], matchWidth / 4 + 5, matchWidth - matchWidth / 4 - 5);

  const ballInBottomPenalyBoxY = isBetween(
    item[1],
    matchHeight - matchHeight / 6 - 7,
    matchHeight + 1,
  );

  return ballInPenalyBoxX && ballInBottomPenalyBoxY;
}

function getRandomTopPenaltyPosition(matchDetails: MatchDetails): [number, number] {
  const [pitchWidth, pitchHeight] = matchDetails.pitchSize;

  const boundaryX = [pitchWidth / 4 + 6, pitchWidth - pitchWidth / 4 - 6];

  const boundaryY = [0, pitchHeight / 6 + 6];

  return [getRandomNumber(boundaryX[0], boundaryX[1]), getRandomNumber(boundaryY[0], boundaryY[1])];
}

function getRandomBottomPenaltyPosition(matchDetails: MatchDetails): [number, number] {
  const [pitchWidth, pitchHeight] = matchDetails.pitchSize;

  const boundaryX = [pitchWidth / 4 + 6, pitchWidth - pitchWidth / 4 - 6];

  const boundaryY = [pitchHeight - pitchHeight / 6 + 6, pitchHeight];

  return [getRandomNumber(boundaryX[0], boundaryX[1]), getRandomNumber(boundaryY[0], boundaryY[1])];
}

function isEven(n: number): boolean {
  return n % 2 === 0;
}

function isOdd(n: number): boolean {
  return Math.abs(n % 2) === 1;
}

function removeBallFromAllPlayers(matchDetails: MatchDetails): void {
  for (const player of matchDetails.kickOffTeam.players) {
    player.hasBall = false;
  }

  for (const player of matchDetails.secondTeam.players) {
    player.hasBall = false;
  }
}

/**
 * Safely updates a player's position tuple.
 * Uses Object.defineProperty to bypass runtime 'writable: false' constraints.
 */
function setPlayerXY(player: Player, x: number | 'NP', y: number): void {
  safeSet(player, 'currentPOS', [x, y]);
}

/**
 * Safely updates the ball's position.
 * Bypasses readonly constraints using Object.defineProperty to ensure
 * compatibility with frozen objects in test environments.
 */
function setBallPosition(ball: Ball, x: number, y: number, z?: number): void {
  const newPos: BallPosition = z !== undefined ? [x, y, z] : [x, y];

  safeSet(ball, 'position', newPos);
}

/**
 * Internal helper to bypass readonly constraints and avoid
 * Firefox 'redefine non-configurable' errors.
 */
function safeSet<T extends object, K extends keyof T>(obj: T, key: K, value: T[K]): void {
  const descriptor = Object.getOwnPropertyDescriptor(obj, key);

  // 1. Narrow the object to a Record to allow indexed access safely
  const targetObj = obj as Record<K, unknown>;

  if (descriptor && descriptor.configurable === false) {
    try {
      targetObj[key] = value;
    } catch (error) {
      // 2. Narrow the error and the target values
      const targetValue = targetObj[key];

      if (Array.isArray(targetValue) && Array.isArray(value)) {
        // Use a typed reference to avoid 'error' member access errors
        const targetArray = targetValue as unknown[];

        value.forEach((val: unknown, i: number) => {
          targetArray[i] = val;
        });
      } else {
        logger.error(`Property ${String(key)} is locked (non-configurable).`, error);
      }
    }

    return;
  }

  Object.defineProperty(obj, key, {
    value,
    writable: true,
    enumerable: true,
    configurable: true,
  });
}

/**
 * Updates player position using an existing tuple.
 */
function setPlayerPos(player: Player, pos: readonly [number | 'NP', number]): void {
  // We call our internal XY setter to keep the 'any' cast in one place
  setPlayerXY(player, pos[0], pos[1]);
}

function destructPos(position: readonly [number | 'NP', number]): [number, number] {
  if (!position) {
    throw new Error('Position is undefined');
  }

  const x = position[0];

  if (x === 'NP') {
    throw new Error('Not playing.');
  }

  const y = position[1];

  return [x, y];
}

export {
  aTimesbDividedByC,
  calculatePower,
  getRandomBottomPenaltyPosition,
  getRandomNumber,
  getRandomTopPenaltyPosition,
  inBottomPenalty,
  inTopPenalty,
  isBetween,
  isEven,
  isOdd,
  removeBallFromAllPlayers,
  round,
  setBallPosition,
  setPlayerPos,
  setPlayerXY,
  sumFrom1toX,
  upToMax,
  upToMin,
  destructPos,
  setMatchSeed,
};

export { getBallTrajectory } from './common/getBallTrajectory.js';
