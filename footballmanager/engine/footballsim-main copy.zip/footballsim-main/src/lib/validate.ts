import * as common from './common.js';
import { logger } from './logger.js';
import type { MatchDetails, PitchDetails, Player, Team } from './types.js';

function validateTeam(team: Team): void {
  if (!team.name) {
    throw new Error(`No team name given.`);
  } else {
    validateNumberOfPlayers(team.players);

    for (const player of team.players) {
      validatePlayerObjects(player);
    }
  }
}

function validateTeamSecondHalf(team: Team): void {
  if (!team.name) {
    throw new Error(`No team name given.`);
  } else if (!team.intent) {
    throw new Error(`No team intent given.`);
  } else if (!team.teamID) {
    throw new Error(`No team ID given.`);
  } else {
    validateNumberOfPlayers(team.players);

    for (const player of team.players) {
      validatePlayerObjectsIteration(player);
    }
  }
}

function validateNumberOfPlayers(players: Player[]): void {
  if (players.length !== 11) {
    throw new Error(`There must be 11 players in a team`);
  }
}

function validatePlayerObjects(player: Player): void {
  const playerObjects = [`name`, `position`, `rating`, `currentPOS`, `injured`, `fitness`];

  for (const obj of playerObjects) {
    if (!Object.prototype.hasOwnProperty.call(player, obj)) {
      throw new Error(`Player must contain JSON variable: ${obj}`);
    }
  }

  validatePlayerSkills(player.skill);
}

function validatePlayerObjectsIteration(player: Player): void {
  const playerObjects = [
    `playerID`,
    `name`,
    `position`,
    `rating`,
    `currentPOS`,
    `injured`,
    `fitness`,
  ];

  playerObjects.push(`originPOS`, `intentPOS`, `action`, `offside`, `hasBall`, `stats`);

  for (const obj of playerObjects) {
    if (!Object.prototype.hasOwnProperty.call(player, obj)) {
      throw new Error(`Player must contain JSON variable: ${obj}`);
    }
  }

  validatePlayerSkills(player.skill);
  validateStats(player.stats);
}

function validateStats(stats: unknown): void {
  const statsObject = [`cards`, `goals`, `tackles`, `passes`, `shots`];

  let badObjects = 0;

  for (const type of statsObject) {
    if (!Object.prototype.hasOwnProperty.call(stats, type)) {
      logger.error(`Player must have set stats: ${type}`);
      badObjects++;
    }
  }

  if (badObjects > 0) {
    throw new Error(`Provide Stats: cards,goals,tackles,passes,shots`);
  }
}

function validatePlayerSkills(skills: unknown): void {
  const skillType = [
    `passing`,
    `shooting`,
    `tackling`,
    `saving`,
    `agility`,
    `strength`,
    `penalty_taking`,
    `jumping`,
  ];

  let badObjects = 0;

  for (const type of skillType) {
    if (!Object.prototype.hasOwnProperty.call(skills, type)) {
      logger.error(`Player must contain skill: ${type}`);
      badObjects++;
    }
  }

  if (badObjects > 0) {
    throw new Error(
      `Provide skills: passing,shooting,tackling,saving,agility,strength,penalty_taking,jumping`,
    );
  }
}

function validatePitch(pitchDetails: PitchDetails): void {
  const pitchObjects = [`pitchWidth`, `pitchHeight`];

  let badObjects = 0;

  for (const obj of pitchObjects) {
    if (!Object.prototype.hasOwnProperty.call(pitchDetails, obj)) {
      logger.error(`Pitch Must contain: ${obj}`);
      badObjects++;
    }
  }

  if (badObjects > 0) {
    throw new Error(`Please provide pitchWidth and pitchHeight`);
  }
}

function validateArguments(a: unknown, b: unknown, c: unknown): void {
  if (a === undefined || b === undefined || c === undefined) {
    throw new Error(`Please provide two teams and a pitch`);
  }
}

function validateMatchDetails(matchDetails: MatchDetails): void {
  const matchObjects = [`matchID`, `kickOffTeam`, `secondTeam`, `pitchSize`, `ball`, `half`];

  Array.prototype.push.apply(matchObjects, [
    `kickOffTeamStatistics`,
    `secondTeamStatistics`,
    `iterationLog`,
  ]);
  let badObjects = 0;

  for (const obj of matchObjects) {
    if (matchDetails) {
      if (!Object.prototype.hasOwnProperty.call(matchDetails, obj)) {
        logger.error(`Match Details must contain: ${obj}`);
        badObjects++;
      }
    }

    if (badObjects > 0) {
      throw new Error(`Please provide valid match details JSON`);
    }
  }

  validateBall(matchDetails.ball);
}

function validateBall(ball: unknown): void {
  const ballProps = [
    `position`,
    `withPlayer`,
    `Player`,
    `withTeam`,
    `direction`,
    `ballOverIterations`,
  ];

  let badObjects = 0;

  for (const prop of ballProps) {
    if (!Object.prototype.hasOwnProperty.call(ball, prop)) {
      logger.error(`Ball JSON must have property: ${prop}`);
      badObjects++;
    }
  }

  if (badObjects > 0) {
    throw new Error(`Provide: position,withPlayer,Player,withTeam,direction,ballOverIterations`);
  }
}

function isPlayerInBounds(player: Player, pitchWidth: number, pitchHeight: number): void {
  if (player.currentPOS[0] !== 'NP') {
    const onPitchX = common.isBetween(player.currentPOS[0], -1, pitchWidth + 1);

    const onPitchY = common.isBetween(player.currentPOS[1], -1, pitchHeight + 1);

    if (onPitchX === false) {
      throw new Error(`Player ${player.name} not on the pitch X: ${player.currentPOS[0]}`);
    }

    if (onPitchY === false) {
      throw new Error(`Player ${player.name} not on the pitch Y: ${player.currentPOS[1]}`);
    }
  }
}

function validatePlayerPositions(matchDetails: MatchDetails): void {
  const { kickOffTeam, secondTeam } = matchDetails;

  const [pitchWidth, pitchHeight] = matchDetails.pitchSize;

  for (const player of kickOffTeam.players) {
    isPlayerInBounds(player, pitchWidth, pitchHeight);
  }

  for (const player of secondTeam.players) {
    isPlayerInBounds(player, pitchWidth, pitchHeight);
  }
}

export {
  validateTeam,
  validateTeamSecondHalf,
  validatePitch,
  validateArguments,
  validateMatchDetails,
  validatePlayerPositions,
};
