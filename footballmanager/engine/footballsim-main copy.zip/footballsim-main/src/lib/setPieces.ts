import { calcBallMovementOverTime, checkGoalScored } from './ballMovement.js';
import * as common from './common.js';
import { setBallPossession } from './setFreekicks.js';
import { calculatePenaltyTarget } from './setPositions.js';
import { recordShotStats } from './stats.js';
import type { ActionContext, Ball, MatchDetails, Player, Team } from './types.js';

function executePenaltyShot(
  matchDetails: MatchDetails,
  team: Team,
  player: Player,
): [number, number] {
  // 1. Initialize State
  player.action = `none`;
  matchDetails.iterationLog.push(`Penalty Taken by: ${player.name}`);

  Object.assign(matchDetails.ball.lastTouch, {
    playerName: player.name,
    playerID: player.playerID,
    teamID: team.teamID,
  });

  // 2. Determine Outcome and Record Stats
  const isOnTarget = player.skill.penalty_taking > common.getRandomNumber(0, 100);

  recordShotStats(matchDetails, player, isOnTarget);

  // 3. Calculate Target Position
  const shotPosition = calculatePenaltyTarget(matchDetails.pitchSize, player, isOnTarget);

  matchDetails.iterationLog.push(
    `Shot ${isOnTarget ? 'On' : 'Off'} Target at X: ${shotPosition[0]}`,
  );

  // 4. Execution & Physics
  const endPos = calcBallMovementOverTime(
    matchDetails,
    player.skill.strength,
    shotPosition,
    player,
  );

  checkGoalScored(matchDetails);

  return endPos;
}

/**
 * Calculates the Y-coordinate for an attacking player during a deep set piece.
 */
function calculateAttackingSetPieceY(yPositionConfig: {
  player: Player;
  ballY: number;
  isTopDirection: boolean;
  pitchHeight: number;
  isGKExecuting: boolean;
}): number {
  const { player, ballY, isTopDirection: isTop, pitchHeight, isGKExecuting } = yPositionConfig;

  const offset = isTop ? 300 : -300;

  const baseNewY = isGKExecuting
    ? player.originPOS[1] + offset
    : player.originPOS[1] + (ballY - player.originPOS[1]) + offset;

  const limit = getAttackingLimit(player.position, isTop, pitchHeight);

  return isTop ? common.upToMax(baseNewY, limit) : common.upToMin(baseNewY, limit);
}

/**
 * Calculates the Y-coordinate for a defensive player during a deep set piece.
 */
function calculateDefensiveSetPieceY(attackingYConfig: {
  player: Player;
  ballY: number;
  isTop: boolean;
  pitchHeight: number;
  isGKExecuting: boolean;
}): number {
  const { player, isTop, pitchHeight, isGKExecuting } = attackingYConfig;

  if (isGKExecuting) {
    if (player.position === 'GK') {
      return player.originPOS[1];
    }

    return isTop
      ? common.upToMin(player.originPOS[1] - 100, 0)
      : common.upToMax(player.originPOS[1] + 100, pitchHeight);
  }

  if (['GK', 'CB', 'LB', 'RB'].includes(player.position)) {
    return player.originPOS[1];
  }

  return getDefensiveTargetY(player.position, isTop, pitchHeight);
}

/**
 * Orchestrates the setup for a deep set piece.
 * Refactored to meet max-length metrics by delegating team positioning.
 */
function executeDeepSetPieceSetup(
  matchDetails: MatchDetails,
  attack: Team,
  defence: Team,
  side: 'top' | 'bottom',
): MatchDetails {
  const isTop = side === 'top';

  const { ball } = matchDetails;

  const [, pitchHeight] = matchDetails.pitchSize;

  // 1. Identify Kicker
  const kickPlayer = selectDeepSetPieceKicker(ball, attack, isTop, pitchHeight);

  const isGKExecuting = kickPlayer.position === 'GK';

  // 2. Set Possession & Ball State
  setBallPossession(kickPlayer, ball, attack);
  ball.direction = isTop ? 'south' : 'north';

  // 3. Position Teams
  repositionAttackers({
    team: attack,
    player: kickPlayer,
    ball: ball,
    isTopDirection: isTop,
    pitchHeight: pitchHeight,
    isGKExecuting: isGKExecuting,
  });
  repositionDefenders({
    attack: defence,
    kickPlayer,
    ball,
    isTop,
    pitchHeight,
    isGKExecuting,
  });

  matchDetails.endIteration = true;

  return matchDetails;
}

/**
 * Logic to determine if the GK or a defender takes the deep kick.
 */
function selectDeepSetPieceKicker(
  ball: Ball,
  attack: Team,
  isTop: boolean,
  pitchHeight: number,
): Player {
  const goalieAreaLimit = isTop ? pitchHeight * 0.25 + 1 : pitchHeight * 0.75 - 1;

  const goalieToKick = isTop
    ? ball.position[1] <= goalieAreaLimit
    : ball.position[1] >= goalieAreaLimit;

  return goalieToKick ? attack.players[0] : attack.players[3];
}

/**
 * Iterates through attacking players to set coordinates.
 */
function repositionAttackers(repositionConfig: {
  team: Team;
  player: Player;
  ball: Ball;
  isTopDirection: boolean;
  pitchHeight: number;
  isGKExecuting: boolean;
}): void {
  const {
    team: attack,
    player: kickPlayer,
    ball,
    isTopDirection: isTop,
    pitchHeight,
    isGKExecuting,
  } = repositionConfig;

  for (const player of attack.players) {
    if (player.name === kickPlayer.name) {
      common.setPlayerXY(player, ball.position[0], ball.position[1]);
    } else {
      const finalY = calculateAttackingSetPieceY({
        player: player,
        ballY: ball.position[1],
        isTopDirection: isTop,
        pitchHeight: pitchHeight,
        isGKExecuting: isGKExecuting,
      });

      common.setPlayerXY(player, player.originPOS[0], player.currentPOS[1]);
      common.setPlayerXY(player, player.currentPOS[0], Math.floor(finalY));
    }
  }
}

/**
 * Iterates through defensive players to set coordinates.
 */
function repositionDefenders(attackerRepositionConfig: {
  attack: Team;
  kickPlayer: Player;
  ball: Ball;
  isTop: boolean;
  pitchHeight: number;
  isGKExecuting: boolean;
}): void {
  const { attack, ball, isTop, pitchHeight, isGKExecuting } = attackerRepositionConfig;

  for (const player of attack.players) {
    const targetY = calculateDefensiveSetPieceY({
      player: player,
      ballY: ball.position[1], // Use the actual ball Y coordinate
      isTop: isTop, // Use the boolean flag
      pitchHeight: pitchHeight, // Use the actual pitch height
      isGKExecuting: isGKExecuting,
    });

    common.setPlayerXY(player, player.originPOS[0], player.currentPOS[1]);
    common.setPlayerXY(player, player.currentPOS[0], Math.floor(targetY));
  }
}

/**
 * Helper: Defines the furthest forward a player can move during a set piece
 */
function getAttackingLimit(pos: string, isTop: boolean, pitchHeight: number): number {
  if (pos === 'GK') {
    return isTop ? pitchHeight * 0.25 : pitchHeight * 0.75;
  }

  if (['CB', 'LB', 'RB'].includes(pos)) {
    return pitchHeight * 0.5;
  }

  if (['CM', 'LM', 'RM'].includes(pos)) {
    return isTop ? pitchHeight * 0.75 : pitchHeight * 0.25;
  }

  return isTop ? pitchHeight * 0.9 : pitchHeight * 0.1;
}

/**
 * Helper: Defines target lines for the defending team
 */
function getDefensiveTargetY(pos: string, isTop: boolean, pitchHeight: number): number {
  const isMid = ['CM', 'LM', 'RM'].includes(pos);

  if (isMid) {
    return isTop ? pitchHeight * 0.75 + 5 : pitchHeight * 0.25 - 5;
  }

  return pitchHeight * 0.5;
}

/**
 * Calculates the target X for the defensive wall.
 */
function calculateDefensiveWallX(ballX: number, pitchWidth: number): number {
  const ballDistanceFromGoalX = ballX - pitchWidth / 2;

  return Math.floor((ballX - ballDistanceFromGoalX) / 2);
}

/**
 * Determines the Y coordinate for attackers based on their role.
 */
function getAttackerSetPieceY(
  position: string,
  pitchHeight: number,
  isTop: boolean,
): number | null {
  if (position === 'GK') {
    return Math.floor(pitchHeight * (isTop ? 0.25 : 0.75));
  }

  if (position === 'CB') {
    return Math.floor(pitchHeight * 0.5);
  }

  if (position === 'LB' || position === 'RB') {
    return Math.floor(pitchHeight * (isTop ? 0.66 : 0.33));
  }

  return null;
}

/**
 * Orchestrates team repositioning for set pieces.
 * Adheres to 4-parameter limit per function.
 */
function repositionTeamsForSetPiece(
  config: ActionContext & {
    pitchHeight: number;
    ball: Ball;
    pitchWidth: number;
    isTop: boolean;
  },
): MatchDetails {
  const { team, player, matchDetails, isTop } = config;

  const getRandomPos = isTop
    ? common.getRandomBottomPenaltyPosition
    : common.getRandomTopPenaltyPosition;

  // 1. POSITION ATTACK
  applyAttackerPositions(team, config.pitchHeight, isTop);
  fillRemainingAttackers(team, player, matchDetails, getRandomPos);

  // 2. POSITION DEFENCE
  applyDefenderPositions(config, matchDetails, getRandomPos);

  matchDetails.endIteration = true;

  return matchDetails;
}

/**
 * Handles fixed-positioning for attacking backline players.
 */
function applyAttackerPositions(team: Team, pitchHeight: number, isTop: boolean): void {
  for (const p of team.players) {
    const targetY = getAttackerSetPieceY(p.position, pitchHeight, isTop);

    if (targetY !== null) {
      common.setPlayerXY(p, p.originPOS[0], targetY);
    }
  }
}

/**
 * Places non-backline attackers (excluding the kicker) into random penalty positions.
 */
function fillRemainingAttackers(
  team: Team,
  kicker: Player,
  state: MatchDetails,
  getRandomPos: (s: MatchDetails) => [number, number],
): void {
  for (const p of team.players) {
    const isBackLine = getAttackerSetPieceY(p.position, 0, false) !== null;

    if (!isBackLine && p.playerID !== kicker.playerID) {
      common.setPlayerPos(p, getRandomPos(state));
    }
  }
}

/**
 * Handles defensive positioning, including the goalkeeper and the defensive wall.
 */
function applyDefenderPositions(
  config: { opp: Team; ball: Ball; pitchHeight: number; pitchWidth: number; isTop: boolean },
  state: MatchDetails,
  getRandomPos: (s: MatchDetails) => [number, number],
): void {
  const { opp, ball, pitchHeight, pitchWidth, isTop } = config;

  const wallX = calculateDefensiveWallX(ball.position[0], pitchWidth);

  let pSpace = isTop
    ? common.upToMax(ball.position[1] + 3, pitchHeight)
    : common.upToMin(ball.position[1] - 3, 0);

  for (const p of opp.players) {
    if (p.position === 'GK') {
      common.setPlayerPos(p, [...p.originPOS]); // Reference preservation
    } else if (['CB', 'LB', 'RB'].includes(p.position)) {
      common.setPlayerXY(p, wallX, pSpace);
      pSpace = isTop ? pSpace - 2 : pSpace + 2; // Logic preservation
    } else {
      common.setPlayerPos(p, getRandomPos(state));
    }
  }
}

export { executePenaltyShot, executeDeepSetPieceSetup, repositionTeamsForSetPiece };

export { setPenaltyPositions } from './position/penaltyArea.js';
